//var host="http://192.168.1.9:8181";
//var esn = "2E0000000000002E";
var host = ""; //same origin
var esn = "2E0000000000002E";
var dataTemplate = {
	"name": esn,
	"params": {
		"location": "上海世博展览馆",
		"energy": "N/A",
		"voltage": "N/A",
		"current": "N/A",
		"power": "N/A",
		"frequency": "N/A"
	},
	"status": 1
};

//  "huawei-iotdm-device-energy:frequency":"frequency"	//频率
//  "huawei-iotdm-device-energy:a-voltage":"voltage",	//电压
//  "huawei-iotdm-device-energy:a-current":"current",	//电流
//  "huawei-iotdm-device-energy:total-active-power":"power",	//g功率
//  "huawei-iotdm-device-energy:total-active-energy":"energy",	//电能

function bultGet(){
    $.ajax({
        type: "POST",
        url: host+"/iotdm/nb/v1/system/action/urn:huawei:iotdm:task/bulk-get",
        contentType: 'application/json',
		dataType :'json',
		data:JSON.stringify({
			"devices":[esn], /*设备编号*/
			"priority":1,/*必选，优先等级，1~10*/
			"retry-times":3, /*必选，重试次数，0~100*/
			"retry-intervals":100,/*必选，重试间隔，0~65535，毫秒*/
			"max-timeout":20000,/*必选，超时时间范围，1000~300000，毫秒*/
			"action":[{//DEMO FREQUENCY
				"name":"frequency", 
				"type":"get",
				"path":"/huawei-iotdm-device:data/huawei-iotdm-device-energy:???"
			},{//请采集其他数据项（电压）
				"name":"voltage", 
				"type":"get",
				"path":"/huawei-iotdm-device:data/huawei-iotdm-device-energy:????"
			},{//请采集其他数据项（电流）
				"name":"current", 
				"type":"get",
				"path":"/huawei-iotdm-device:data/huawei-iotdm-device-energy:????"
			},{//请采集其他数据项（功率）
				"name":"power", 
				"type":"get",
				"path":"/huawei-iotdm-device:data/huawei-iotdm-device-energy:????"
			},{//请采集其他数据项（能量）
				"name":"energy", 
				"type":"get",
				"path":"/huawei-iotdm-device:data/huawei-iotdm-device-energy:????"
			}]
		}),
        success: function(msg){
			var devData = $.extend({},dataTemplate);
			var actions = msg.logs[0].action;
			var isOnline=false;
			actions.forEach(function(element, index, array){
				if(element.status=='completed'){
					//只要有一个成功，那么肯定在线
					devData.status=1;
				}
				if(devData.params[element.name]){
					devData.params[element.name]=element.result;
				}
			});
			if(devData.status==1){
				showData(devData);
				return;
			}
			alert('请求出错了');
			try{//错了就记录日志
				console.log(JSON.strinify(msg));	
			}catch(e){}
       },
		error:function(jqXHR,textStatus,errorThrown ){
				alert('出错了');
		}
	});
}

function singleGet() {
	var devData = $.extend({}, dataTemplate);

	//请采集其他数据项（频率）
	$.getJSON(host + "/iotdm/nb/v1/device/get/" + esn + "/urn:huawei:iotdm:device/data/huawei-iotdm-device-energy:？？？", function(data) {
		devData.params.？？？？ = data;
		showData(devData);
	});
	//请采集其他数据项（电压）
	$.getJSON(host + "/iotdm/nb/v1/device/get/" + esn + "/urn:huawei:iotdm:device/data/huawei-iotdm-device-energy:？？？", function(data) {
		devData.params.？？？？ = data;
		showData(devData);
	});
	//请采集其他数据项（电流）
	$.getJSON(host + "/iotdm/nb/v1/device/get/" + esn + "/urn:huawei:iotdm:device/data/huawei-iotdm-device-energy:？？？", function(data) {
		devData.params.？？？？ = data;
		showData(devData);
	});
	//请采集其他数据项（功率）
	$.getJSON(host + "/iotdm/nb/v1/device/get/" + esn + "/urn:huawei:iotdm:device/data/huawei-iotdm-device-energy:？？？", function(data) {
		devData.params.？？？？ = data;
		showData(devData);
	});
	//请采集其他数据项（能量）
	$.getJSON(host + "/iotdm/nb/v1/device/get/" + esn + "/urn:huawei:iotdm:device/data/huawei-iotdm-device-energy:？？？", function(data) {
		devData.params.？？？？ = data;
		showData(devData);
	});
}

function getEnergyInfo(id) {
	//批量获取
	bultGet();
	//单个获取
	singleGet();

}

function showData(msg) {
	$('#deviceId').html(msg.name);
	$('#location').html(msg.params.location);
	//六个值
	$('#voltage').html(msg.params.voltage);
	$('#current').html(msg.params.current);
	$('#power').html(msg.params.power);
	$('#frequency').html(msg.params.frequency);
	$('#energy').html(msg.params.energy);
	if (msg.status == 1) {
		$("#status").html("Online");
	} else {
		$("#status").html("Offline");
	}
	//进度条
	//$('#lifetime').html(msg.params.lifttime);
	//$('.Jprogess').css({width:msg.params.lifttime+'%'});
}
getEnergyInfo();